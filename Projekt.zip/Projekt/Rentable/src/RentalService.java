import java.util.ArrayList;

public class RentalService {
    ArrayList<Car> cars = new ArrayList<>();
    double totalRevenue = 0;

    public void addCar(Car c) {
        cars.add(c);
    }

    public void printCars() {
        for (Car c : cars) {
            System.out.println(c);
        }
    }

    public void rentCar(String vin, int days) {
        for (Car c : cars) {
            if (c.vin.equals(vin) && !c.rented) {
                double cost = c.rent(days);
                totalRevenue += cost;
                c.rented = true;
                System.out.println("Wynajęto: " + c.brand + " " + c.model + " za " + cost + " zł");
                return;
            }
        }
        System.out.println("Nie znaleziono dostępnego auta o VIN: " + vin);
    }

    public void showRevenue() {
        System.out.println("Łączny przychód: " + totalRevenue + " zł");
    }
}

