
public class Car {
    String vin;
    String brand;
    String model;
    int year;
    String color;
    boolean rented;

    public Car(String vin, String brand, String model, int year, String color) {
        this.vin = vin;
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.color = color;
        this.rented = false;
    }

    public double rent(int days) {
        return days * 100;
    }

    public String toString() {
        return brand + " " + model + " (" + year + "), VIN: " + vin + ", Kolor: " + color + (rented ? " [Wynajęty]" : " [Dostępny]");
    }
}
