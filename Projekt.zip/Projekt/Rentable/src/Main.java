import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        RentalService rental = new RentalService();
        Scanner scanner = new Scanner(System.in);

        Car c1 = new ElectricCar("1HGCM82633A004352", "Tesla", "Model 3", 2022, "Czarny", 75);
        Car c2 = new DieselCar("2FTRX18L1XCA12345", "BMW", "X5", 2019, "Biały", 3.0);
        Car c3 = new DieselCar("JH4TB2H26CC000000", "Audi", "A4", 2020, "Szary", 2.0);

        rental.addCar(c1);
        rental.addCar(c2);
        rental.addCar(c3);

        boolean running = true;

        while (running) {
            System.out.println("\n--- SYSTEM WYNAJMU SAMOCHODÓW ---");
            System.out.println("1. Wyświetl dostępne samochody");
            System.out.println("2. Wynajmij samochód");
            System.out.println("3. Dodaj nowy samochód");
            System.out.println("4. Pokaż łączny przychód");
            System.out.println("5. Zakończ");
            System.out.print("Wybierz opcję: ");

            String opt = scanner.nextLine();
            int option = 0;
            try {
                option = Integer.parseInt(opt);
            } catch (Exception e) {
                System.out.println("Błąd: wpisz numer od 1 do 5.");
                continue;
            }

            switch (option) {
                case 1:
                    rental.printCars();
                    break;

                case 2:
                    System.out.print("Podaj VIN samochodu: ");
                    String vin = scanner.nextLine().trim();
                    System.out.print("Na ile dni wynająć: ");
                    String daysStr = scanner.nextLine();
                    int days;
                    try {
                        days = Integer.parseInt(daysStr);
                    } catch (Exception e) {
                        System.out.println("Błąd: wpisz poprawną liczbę dni.");
                        break;
                    }
                    rental.rentCar(vin, days);
                    break;

                case 3:
                    System.out.println("Wybierz typ auta:");
                    System.out.println("1. Elektryczne");
                    System.out.println("2. Diesel");
                    String typeStr = scanner.nextLine();
                    int type = 0;
                    try {
                        type = Integer.parseInt(typeStr);
                    } catch (Exception e) {
                        System.out.println("Błąd: wpisz 1 lub 2.");
                        break;
                    }

                    String newVin = "";
                    while (true) {
                        System.out.print("Podaj VIN (17 znaków): ");
                        newVin = scanner.nextLine().trim().toUpperCase();
                        if (newVin.length() == 17 && newVin.matches("[A-HJ-NPR-Z0-9]+")) {
                            break;
                        } else {
                            System.out.println("Niepoprawny VIN. Spróbuj ponownie.");
                        }
                    }

                    System.out.print("Podaj markę: ");
                    String brand = scanner.nextLine();
                    System.out.print("Podaj model: ");
                    String model = scanner.nextLine();

                    int year = 0;
                    while (true) {
                        System.out.print("Podaj rok produkcji: ");
                        String yearStr = scanner.nextLine();
                        try {
                            year = Integer.parseInt(yearStr);
                            break;
                        } catch (Exception e) {
                            System.out.println("Błąd: wpisz liczbę całkowitą (np. 2024).");
                        }
                    }

                    System.out.print("Podaj kolor: ");
                    String color = scanner.nextLine();

                    if (type == 1) {
                        System.out.print("Podaj pojemność baterii (kWh): ");
                        String batStr = scanner.nextLine();
                        try {
                            int battery = Integer.parseInt(batStr);
                            rental.addCar(new ElectricCar(newVin, brand, model, year, color, battery));
                        } catch (Exception e) {
                            System.out.println("Błąd: wpisz liczbę całkowitą.");
                        }
                    } else if (type == 2) {
                        System.out.print("Podaj pojemność silnika (L): ");
                        String engStr = scanner.nextLine().replace(',', '.');
                        try {
                            double engine = Double.parseDouble(engStr);
                            rental.addCar(new DieselCar(newVin, brand, model, year, color, engine));
                        } catch (Exception e) {
                            System.out.println("Błąd: wpisz poprawną liczbę (np. 2.0).");
                        }
                    } else {
                        System.out.println("Niepoprawny typ auta.");
                    }

                    System.out.println("Samochód dodany do systemu.");
                    break;

                case 4:
                    rental.showRevenue();
                    break;

                case 5:
                    running = false;
                    System.out.println("Zamykanie programu...");
                    break;

                default:
                    System.out.println("Nieprawidłowa opcja.");
            }
        }

        scanner.close();
    }
}


