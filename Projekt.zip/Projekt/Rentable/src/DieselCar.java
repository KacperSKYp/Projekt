
public class DieselCar extends Car {
    double engineSize;

    public DieselCar(String vin, String brand, String model, int year, String color, double engineSize) {
        super(vin, brand, model, year, color);
        this.engineSize = engineSize;
    }

    @Override
    public double rent(int days) {
        return days * (80 + engineSize * 10);
    }
}



