public class ElectricCar extends Car {
    int battery;

    public ElectricCar(String vin, String brand, String model, int year, String color, int battery) {
        super(vin, brand, model, year, color);
        this.battery = battery;
    }

    @Override
    public double rent(int days) {
        return days * 120;
    }
}
